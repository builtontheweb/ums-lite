<main>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-6">
				<div class="text-center mt-4">
					<h1 class="display-1">500</h1>
					<p class="lead">Internal Server Error</p>
					<a href="dashboard/index"><i class="fas fa-arrow-left mr-1"></i>Return to Dashboard</a>
				</div>
			</div>
		</div>
	</div>
</main>